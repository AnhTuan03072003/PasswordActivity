rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache/GCloudSDKLog/GCloud/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/cacheFile.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/ca-bundle.pem > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/Epic Games/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf  /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/tencent/Midas/Log/com.vng.pubgmobile/* > /dev/null 2>&1
rm -rf /storage/emulated/0/MidasOversea/* > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/app_crashrecord/* > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/code_cache/* > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/cache/* > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/no_backups/* > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/databases/* > /dev/null 2>&1
rm -rf /data/data/com.vng.pubgmobile/app_bugly/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache/GCloudSDKLog/GCloud/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/login-identifier.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/cacheFile.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/ca-bundle.pem > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Epic Games/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf  /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/tencent/Midas/Log/com.tencent.ig/* > /dev/null 2>&1
rm -rf /storage/emulated/0/MidasOversea/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/app_crashrecord/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/code_cache/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/cache/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/no_backups/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/databases/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/app_bugly/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache/GCloudSDKLog/GCloud/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/login-identifier.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/cacheFile.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/Epic Games/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf  /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/tencent/Midas/Log/com.pubg.krmobile/* > /dev/null 2>&1
rm -rf /storage/emulated/0/MidasOversea/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/app_crashrecord/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/code_cache/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/cache/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/no_backups/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/databases/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.krmobile/app_bugly/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/cache/GCloudSDKLog/GCloud/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/login-identifier.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/cacheFile.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/ca-bundle.pem > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/Epic Games/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf  /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/tencent/Midas/Log/com.pubg.imobile/* > /dev/null 2>&1
rm -rf /storage/emulated/0/MidasOversea/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.imobile/app_crashrecord/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.imobile/code_cache/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.imobile/cache/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.imobile/no_backups/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.imobile/databases/* > /dev/null 2>&1
rm -rf /data/data/com.pubg.imobile/app_bugly/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache/GCloudSDKLog/GCloud/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/login-identifier.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/cacheFile.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/ca-bundle.pem > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/Epic Games/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf  /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/tencent/Midas/Log/com.rekoo.pubgm/* > /dev/null 2>&1
rm -rf /storage/emulated/0/MidasOversea/* > /dev/null 2>&1
rm -rf /data/data/com.rekoo.pubgm/app_crashrecord/* > /dev/null 2>&1
rm -rf /data/data/com.rekoo.pubgm/code_cache/* > /dev/null 2>&1
rm -rf /data/data/com.rekoo.pubgm/cache/* > /dev/null 2>&1
rm -rf /data/data/com.rekoo.pubgm/no_backups/* > /dev/null 2>&1
rm -rf /data/data/com.rekoo.pubgm/databases/* > /dev/null 2>&1
rm -rf /data/data/com.rekoo.pubgm/app_bugly/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/cache/GCloudSDKLog/GCloud/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/login-identifier.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/cacheFile.txt > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/ca-bundle.pem > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/Engine/Saved/Config/Android/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/Epic Games/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/* > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots > /dev/null 2>&1
rm -rf /data/media/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/GEM/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Arena/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Match/* > /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf  /storage/emulated/0/Android/data/com.tencent.tmgp.pubgmhd/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/tencent/Midas/Log/com.tencent.tmgp.pubgmhd/* > /dev/null 2>&1
rm -rf /storage/emulated/0/MidasOversea/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.tmgp.pubgmhd/app_crashrecord/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.tmgp.pubgmhd/code_cache/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.tmgp.pubgmhd/cache/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.tmgp.pubgmhd/no_backups/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.tmgp.pubgmhd/databases/* > /dev/null 2>&1
rm -rf /data/data/com.tencent.tmgp.pubgmhd/app_bugly/* > /dev/null 2>&1




