rm -rf /data/data/com.vng.pubgmobile/app_crashrecord/
rm -rf /data/data/com.vng.pubgmobile/app_crashSight/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
